const telegram = require('./telegram');

module.exports.processWebhook = async event => {
    const body = JSON.parse(event.body);

    console.log(body); // Логируем body


        const { chat, text } = body.name;

        await telegram.sendMessage({ chat_id: -614387571,
           text:
            body.id
            + "\n" +
            body.name
            + "\n" +
            body.vd
            + "\n" +
            body.tp
            + "\n" +
            body.tel
            + "\n" +
            body.email
         });


    return { statusCode: 200 };
};
